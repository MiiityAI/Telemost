import requests
import logging
from typing import Dict, Optional
from datetime import datetime
from pathlib import Path
import argparse
import sys
import re
import json
import time

class MistralClient:
    def __init__(self, api_url: str):
        self.api_url = api_url
        self.logger = logging.getLogger(__name__)
        self.session = requests.Session()
        self.timeout = 300
        self.max_retries = 3

    def _create_chat_messages(self, query: str, context: str, is_insight: bool = True) -> list:
        """Создает сообщения для чата"""
        system_message = "You are a helpful AI assistant that analyzes documents and provides insights or tasks."
        task_type = "an insightful observation" if is_insight else "a specific, actionable task"
        
        # Формирование запроса
        user_prompt = f"""Based on the following context from the vault, generate {task_type}.

Context:
{context}

Query:
{query}

Please provide a clear and concise response that could be valuable for the vault owner."""
        
        messages = [
            {"role": "assistant", "content": system_message},
            {"role": "user", "content": user_prompt}
        ]
        
        # Если общий текст слишком большой, обрежем контекст
        total_length = sum(len(m['content']) for m in messages)
        if total_length > 10000:  # условный лимит — можно корректировать
            self.logger.warning("Request payload too long, trimming context.")
            # Усечём контекст до первых 2000 символов
            context = context[:2000] + "...[truncated]..."
            messages[1]["content"] = f"Context:\n{context}\n\nQuery:\n{query}"
        
        return messages

    def _make_request(self, messages: list) -> Optional[str]:
        """Делает запрос к API с повторными попытками"""
        for attempt in range(self.max_retries):
            try:
                self.logger.info(f"Making API request (attempt {attempt + 1}/{self.max_retries})")
                
                response = self.session.post(
                    self.api_url,
                    json={
                        "messages": messages,
                        "temperature": 0.7,
                        "max_tokens": 500
                    },
                    timeout=self.timeout
                )
                response.raise_for_status()
                
                result = response.json()
                if 'choices' in result and len(result['choices']) > 0:
                    return result['choices'][0]['message']['content']
                else:
                    self.logger.error(f"Unexpected API response format: {result}")
                    
            except requests.Timeout:
                self.logger.error(f"Request timeout (attempt {attempt + 1})")
            except requests.RequestException as e:
                self.logger.error(f"Request failed (attempt {attempt + 1}): {e}")
            except Exception as e:
                self.logger.error(f"Unexpected error (attempt {attempt + 1}): {e}")
                
            if attempt < self.max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
                
        return None

    def get_insights(self, query: str, context: str) -> Optional[str]:
        """Получает инсайты от API"""
        try:
            messages = self._create_chat_messages(query, context, is_insight=True)
            return self._make_request(messages)
        except Exception as e:
            self.logger.error(f"Error getting insights: {e}")
            return None

    def get_tasks(self, query: str, context: str) -> Optional[str]:
        """Получает задачи от API"""
        try:
            messages = self._create_chat_messages(query, context, is_insight=False)
            return self._make_request(messages)
        except Exception as e:
            self.logger.error(f"Error getting tasks: {e}")
            return None

    def analyze_vault_completion(self, stats: dict) -> Optional[int]:
        """Анализирует заполненность vault"""
        try:
            query = (
                "You are a critical analyst of knowledge bases. "
                "Based on these vault statistics, estimate the completion percentage (0-100). "
                "Consider:\n"
                "- Quality and quantity of connections between notes\n"
                "- Coverage of key topics\n"
                "- Depth of analysis\n"
                "- Use of tags and categorization\n"
                "Be conservative in your estimate, as there's always room for improvement. "
                "Return only a number between 0-100.\n\n"
                f"Stats:\n{json.dumps(stats, indent=2)}"
            )
            
            response = self.get_insights(query, "")
            if not response:
                return None
                
            try:
                # Извлекаем число из ответа
                completion = int(''.join(filter(str.isdigit, response)))
                return min(100, max(0, completion))  # Ограничиваем значением 0-100
            except ValueError:
                self.logger.error(f"Could not extract number from response: {response}")
                return None
                
        except Exception as e:
            self.logger.error(f"Failed to analyze vault completion: {e}")
            return None

def test_request():
    """Выполняет тестовый запрос к Mistral API"""
    client = MistralClient("http://localhost:1234/v1/chat/completions")
    
    test_query = "Hello, world! This is a test message."
    test_context = "This is a test context for the Mistral API."
    
    print("\n" + "="*50)
    print("🔄 Sending test request to Mistral API")
    print("="*50)
    print(f"Query: {test_query}")
    print(f"Context: {test_context}")
    print("-"*50)
    
    response = client.get_insights(test_query, test_context)
    
    print("\n📝 Response from Mistral:")
    print("-"*50)
    print(response if response else "No response received")
    print("="*50)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Mistral API Client')
    parser.add_argument('--test', action='store_true', help='Run a test request to Mistral API')
    
    args = parser.parse_args()
    
    if args.test:
        test_request()
    else:
        print("Use --test flag to run a test request")
        sys.exit(1) 