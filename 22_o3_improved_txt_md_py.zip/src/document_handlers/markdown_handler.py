import re
import logging
from pathlib import Path
from typing import Optional, Dict, List

class MarkdownHandler:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.stats = {
            'processed_files': 0,
            'failed_files': 0,
            'total_tags': 0,
            'total_links': 0
        }

    def extract_text(self, md_path: Path) -> Optional[str]:
        try:
            self.logger.info(f"Processing Markdown: {md_path}")
            
            with open(md_path, 'r', encoding='utf-8') as f:
                text = f.read()
            
            # Извлекаем метаданные
            tags = re.findall(r'\[\[(.*?)\]\]', text)
            internal_links = re.findall(r'\[([^\]]+)\]\(([^\)]+)\)', text)
            
            # Обновляем статистику
            self.stats['total_tags'] += len(tags)
            self.stats['total_links'] += len(internal_links)
            
            # Очищаем текст
            text = re.sub(r'#{1,6}\s+', '', text)  # Удаляем заголовки
            text = re.sub(r'\[\[([^\]]+)\]\]', r'\1', text)  # Преобразуем теги
            text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', text)  # Преобразуем ссылки
            
            self.stats['processed_files'] += 1
            
            self.logger.info(
                f"Successfully processed {md_path}:\n"
                f"  Tags found: {len(tags)}\n"
                f"  Links found: {len(internal_links)}\n"
                f"  Text length: {len(text)} characters"
            )
            
            return text
            
        except Exception as e:
            self.stats['failed_files'] += 1
            self.logger.error(f"Error processing Markdown {md_path}: {e}")
            return None

    def extract_text_generic(self, file_path: Path) -> Optional[str]:
        """
        Извлекает текст из любых текстовых файлов (не PDF).
        Подходит для .txt, .py, .json и прочих текстовых файлов.
        """
        try:
            self.logger.info(f"Processing generic text file: {file_path}")
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.stats['processed_files'] += 1
            self.logger.info(f"Successfully processed {file_path} (generic text)")
            return text
        except Exception as e:
            self.stats['failed_files'] += 1
            self.logger.error(f"Error processing generic text file {file_path}: {e}")
            return None

    def get_stats(self) -> Dict[str, int]:
        """Возвращает статистику обработки"""
        return self.stats

    def extract_metadata(self, text: str) -> Dict:
        return {
            'tags': self.extract_tags(text),
            'links': self.extract_links(text)
        }

    def clean_markdown(self, text: str) -> str:
        text = re.sub(r'#{1,6}\s+', '', text)  # Remove headers
        text = re.sub(r'\[\[([^\]]+)\]\]', r'\1', text)  # Clean wiki-links
        text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', text)  # Clean MD links
        return text.strip()

    def extract_tags(self, text: str) -> List[str]:
        return re.findall(r'\[\[(.*?)\]\]', text)

    def extract_links(self, text: str) -> List[str]:
        return re.findall(r'\[([^\]]+)\]\(([^\)]+)\)', text) 