from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QTextEdit, QPushButton, QLineEdit, QGroupBox, QMessageBox, QLabel, QProgressBar, QApplication)
from PyQt6.QtCore import Qt, pyqtSlot, QSize, QTimer
from PyQt6.QtGui import QFont
import json
from datetime import datetime
from pathlib import Path
from ..indexing.vectorizer import DocumentVectorizer
from ..ai.mistral_client import MistralClient
import random
from typing import Optional
import logging

class ChatWindow(QMainWindow):
    def __init__(self, vectorizer: DocumentVectorizer, 
                 mistral_client: MistralClient,
                 config,
                 initial_analysis: Optional[str] = None):
        super().__init__()
        self.vectorizer = vectorizer
        self.mistral_client = mistral_client
        self.config = config
        
        # Улучшаем управление состоянием
        self.current_state = {
            'insight': None,
            'context': None,
            'last_query': None,
            'processing': False
        }
        
        self.stats = {
            'insights_generated': 0,
            'tasks_generated': 0,
            'insights_saved': 0,
            'tasks_saved': 0
        }
        
        self.logger = logging.getLogger(__name__)
        self.setup_ui()
        
        # Сохраняем initial_analysis
        if initial_analysis:
            self.current_state['insight'] = {
                'type': 'initial',
                'content': initial_analysis,
                'query': 'Initial vault analysis'
            }
            QTimer.singleShot(100, lambda: self.show_initial_analysis(initial_analysis))

    def setup_ui(self):
        """Настройка пользовательского интерфейса"""
        # Устанавливаем современный стиль (убраны неподдерживаемые свойства)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f0f2f5;
            }
            QGroupBox {
                border: 2px solid #3b82f6;
                border-radius: 8px;
                margin-top: 1ex;
                font-weight: bold;
                background-color: white;
                padding: 15px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: #1d4ed8;
                font-size: 13px;
            }
            QPushButton {
                background-color: #3b82f6;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 15px;
                font-weight: bold;
                font-size: 13px;
                min-width: 120px;
                min-height: 35px;
            }
            QPushButton:hover {
                background-color: #2563eb;
            }
            QPushButton:pressed {
                background-color: #1d4ed8;
            }
            QTextEdit {
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                padding: 10px;
                font-size: 13px;
                line-height: 1.6;
                background-color: white;
                color: #1e40af;
            }
            QTextEdit:focus {
                border-color: #3b82f6;
                outline: none;
            }
            QLabel {
                color: #1e40af;
                font-size: 13px;
                font-weight: 500;
            }
            QProgressBar {
                border: 2px solid #e5e7eb;
                border-radius: 6px;
                text-align: center;
                height: 25px;
                font-weight: bold;
                background-color: white;
                color: #1e40af;
            }
            QProgressBar::chunk {
                background-color: #10b981;
                border-radius: 4px;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Статус и прогресс
        status_group = QGroupBox("📊 Vault Status")
        status_layout = QVBoxLayout()
        status_layout.setSpacing(10)
        
        # Индикатор заполненности vault
        progress_layout = QHBoxLayout()
        self.progress_label = QLabel("Vault completion:")
        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("%p%")
        progress_layout.addWidget(self.progress_label)
        progress_layout.addWidget(self.progress_bar)
        status_layout.addLayout(progress_layout)
        
        # Статус текущей операции
        self.status_label = QLabel("Ready to analyze vault")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status_layout.addWidget(self.status_label)
        
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)
        
        # Область отображения текущего контента
        content_group = QGroupBox("💡 Current Content")
        content_layout = QVBoxLayout()
        content_layout.setSpacing(10)
        
        self.content_display = QTextEdit()
        self.content_display.setReadOnly(True)
        self.content_display.setMinimumHeight(300)
        self.content_display.setFont(QFont("Arial", 11))
        content_layout.addWidget(self.content_display)
        
        # Кнопки подтверждения для контента
        self.confirm_buttons = QWidget()
        confirm_layout = QHBoxLayout(self.confirm_buttons)
        confirm_layout.setSpacing(10)
        
        self.save_btn = QPushButton("✅ Save")
        self.save_btn.clicked.connect(self.save_current_content)
        confirm_layout.addWidget(self.save_btn)
        
        self.skip_btn = QPushButton("❌ Skip")
        self.skip_btn.clicked.connect(self.skip_current_content)
        confirm_layout.addWidget(self.skip_btn)
        
        self.confirm_buttons.hide()
        content_layout.addWidget(self.confirm_buttons)
        
        content_group.setLayout(content_layout)
        layout.addWidget(content_group)
        
        # Кнопки действий
        generator_group = QGroupBox("🎯 Actions")
        generator_layout = QHBoxLayout()
        generator_layout.setSpacing(10)
        
        self.generate_insight_btn = QPushButton("🔍 Generate Insight")
        self.generate_insight_btn.clicked.connect(self.generate_insight)
        generator_layout.addWidget(self.generate_insight_btn)
        
        self.generate_task_btn = QPushButton("📋 Generate Task")
        self.generate_task_btn.clicked.connect(self.generate_task)
        generator_layout.addWidget(self.generate_task_btn)
        
        self.exit_btn = QPushButton("🚪 Exit")
        self.exit_btn.clicked.connect(self.confirm_exit)
        generator_layout.addWidget(self.exit_btn)
        
        generator_group.setLayout(generator_layout)
        layout.addWidget(generator_group)
        
        # Статус и статистика
        self.stats_label = QLabel("Generated: 0 | Saved: 0")
        layout.addWidget(self.stats_label)
        
        # Устанавливаем размер окна и заголовок
        self.setGeometry(100, 100, 800, 700)
        self.setWindowTitle("🧠 Vault Analysis Assistant")
        
        # Инициализируем прогресс
        self.analyze_vault_completion()

    def analyze_vault_completion(self):
        """Анализирует заполненность vault с помощью Mistral"""
        try:
            # Собираем общую информацию о vault
            total_docs = len(self.vectorizer.document_map)
            total_tags = set()
            total_links = 0
            doc_sizes = []
            
            for doc in self.vectorizer.document_map.values():
                tags = doc.get('tags', [])
                total_tags.update(tags)
                total_links += len(tags)
                doc_sizes.append(len(doc.get('chunk_text', '')))
            
            # Формируем запрос к Mistral для оценки vault
            query = ("Analyze this vault statistics and estimate its completion percentage:\n"
                    f"- Total documents: {total_docs}\n"
                    f"- Unique tags: {len(total_tags)}\n"
                    f"- Total connections: {total_links}\n"
                    f"- Average document size: {sum(doc_sizes)/len(doc_sizes) if doc_sizes else 0:.0f} chars\n"
                    "Provide a completion percentage based on:\n"
                    "1. Document interconnectivity\n"
                    "2. Tagging system coverage\n"
                    "3. Content depth\n"
                    "Return only the percentage number.")
            
            response = self.mistral_client.get_insights(query, "")
            
            if response:
                try:
                    # Извлекаем число из ответа
                    completion = int(''.join(filter(str.isdigit, response)))
                    self.progress_bar.setValue(min(100, completion))
                except ValueError:
                    # Если не удалось получить число, используем формулу
                    progress = min(100, ((len(total_tags) * 2 + total_links) / 300) * 100)
                    self.progress_bar.setValue(int(progress))
            
        except Exception as e:
            print(f"Error updating progress: {e}")
            self.progress_bar.setValue(0)

    def set_processing_state(self, is_processing: bool):
        """Управляет состоянием UI во время обработки"""
        self.current_state['processing'] = is_processing
        
        # Используем прямые ссылки на кнопки
        self.generate_insight_btn.setEnabled(not is_processing)
        self.generate_task_btn.setEnabled(not is_processing)
        self.exit_btn.setEnabled(not is_processing)
        self.save_btn.setEnabled(not is_processing)
        self.skip_btn.setEnabled(not is_processing)
        
        if is_processing:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        else:
            QApplication.restoreOverrideCursor()
    
    def generate_insight(self):
        """Генерирует новый инсайт"""
        if self.current_state['processing']:
            return
        
        try:
            self.set_processing_state(True)
            self.status_label.setText("Checking vectorizer state...")
            self.logger.info("Checking vectorizer state...")
            
            # Проверяем состояние индекса
            index_size = len(self.vectorizer.document_map)
            self.logger.info(f"Index status: {index_size} vectors")
            
            if index_size == 0:
                self.status_label.setText("❌ No documents indexed")
                return
            
            # Всегда получаем новый контекст
            context = self._get_relevant_context()
            if not context:
                self.status_label.setText("❌ Failed to get context")
                return
            
            self.logger.info("Requesting insight from Mistral...")
            self.status_label.setText("🤔 Generating insight...")
            
            # Формируем запрос
            query = ("Analyze the provided context and generate an insightful observation. "
                    "Focus on identifying patterns, connections, and unique perspectives.")
                    
            insight = self.mistral_client.get_insights(query, context)
            
            if insight:
                self.logger.info("Successfully generated insight")
                # Обновляем состояние с новым контекстом
                self.current_state.update({
                    'insight': {
                        'type': 'insight',
                        'content': insight,
                        'query': query
                    },
                    'context': context,  # Сохраняем новый контекст
                    'last_query': query
                })
                
                # Показываем результат
                self.content_display.setText(insight)
                self.confirm_buttons.show()
                self.status_label.setText("✨ New insight generated")
                self.stats['insights_generated'] += 1
                self.update_stats_display()
            else:
                self.logger.error("Mistral returned empty content")
                self.status_label.setText("❌ Failed to generate insight")
            
        except Exception as e:
            self.logger.error(f"Error generating insight: {str(e)}")
            self.status_label.setText(f"❌ Error: {str(e)}")
        finally:
            self.set_processing_state(False)

    def _get_relevant_context(self) -> str:
        """Получает случайный контекст для генерации"""
        try:
            # Конвертируем document_map в список для случайного выбора
            all_docs = list(self.vectorizer.document_map.items())
            if not all_docs:
                return ""
            
            # Выбираем случайные 5 документов
            selected_docs = random.sample(
                all_docs, 
                min(5, len(all_docs))  # Берем 5 или меньше, если документов меньше 5
            )
            
            context = []
            for doc_id, doc in selected_docs:
                context.append(f"Document: {doc['file_path']}\n{doc['chunk_text']}\n")
            
            self.logger.debug(f"Selected {len(context)} random documents for context")
            return "\n---\n".join(context)
            
        except Exception as e:
            self.logger.error(f"Error getting random context: {str(e)}")
            return ""

    def generate_task(self):
        """Генерирует новую задачу, используя случайный контекст"""
        if self.current_state['processing']:
            return
        
        try:
            self.set_processing_state(True)
            self.status_label.setText("Checking vectorizer state...")
            
            # Проверяем состояние индекса
            index_size = len(self.vectorizer.document_map)
            self.logger.info(f"Index status: {index_size} vectors")
            
            if index_size == 0:
                self.status_label.setText("❌ No documents indexed")
                return
            
            # Получаем случайный контекст
            context = self._get_relevant_context()
            if not context:
                self.status_label.setText("❌ Failed to get context")
                return
            
            self.logger.info("Requesting task from Mistral...")
            self.status_label.setText("🤔 Generating task...")
            
            query = ("Based on the provided context, generate a meaningful task or action item. "
                    "Focus on practical steps that would improve or develop the discussed topics.")
            
            task = self.mistral_client.get_insights(query, context)
            
            if task:
                self.logger.info("Successfully generated task")
                self.current_state.update({
                    'insight': {
                        'type': 'task',
                        'content': task,
                        'query': query
                    },
                    'context': context,
                    'last_query': query
                })
                
                self.content_display.setText(task)
                self.confirm_buttons.show()
                self.status_label.setText("✨ New task generated")
                self.stats['tasks_generated'] += 1
                self.update_stats_display()
            else:
                self.logger.error("Mistral returned empty content")
                self.status_label.setText("❌ Failed to generate task")
            
        except Exception as e:
            self.logger.error(f"Error generating task: {str(e)}")
            self.status_label.setText(f"❌ Error: {str(e)}")
        finally:
            self.set_processing_state(False)

    def show_recent_files(self):
        """Показывает последние сохраненные файлы"""
        try:
            oracle_dir = Path(__file__).parent.parent.parent / 'Oracle' / '_AI_Recommendations'
            files = sorted(oracle_dir.glob('*.md'), key=lambda x: x.stat().st_mtime, reverse=True)[:5]
            
            if not files:
                self.add_message("System", "No files found in Oracle/_AI_Recommendations")
                return
                
            self.add_message("System", "Recent files in Oracle/_AI_Recommendations:")
            for file in files:
                with open(file, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.add_message("System", f"\nFile: {file.name}\n{'-'*50}\n{content[:200]}...\n")
                
        except Exception as e:
            self.add_message("System", f"Error reading recent files: {str(e)}")

    def update_stats_display(self):
        """Обновляет отображение статистики"""
        # Используем status_label вместо stats_label
        stats_text = (
            f"Generated: {self.stats['insights_generated']} insights, "
            f"{self.stats['tasks_generated']} tasks | "
            f"Saved: {self.stats['insights_saved']} insights, "
            f"{self.stats['tasks_saved']} tasks"
        )
        self.status_label.setText(stats_text)

    def _generate_content(self, query: str, content_type: str):
        """Генерирует новый контент"""
        try:
            self.set_processing_state(True)
            self.clear_current_insight()  # Очищаем предыдущий контент
            self.content_display.setText("🤔 Generating new content, please wait...")  # Показываем процесс
            self.status_label.setText(f"Generating {content_type}...")
            
            # Получаем контекст
            query_vector = self.vectorizer.model.encode([query])
            distances, indices = self.vectorizer.index.search(query_vector, k=10)
            
            context = "\n".join([
                f"Document: {self.vectorizer.document_map[idx]['file_path']}\n"
                f"Content: {self.vectorizer.document_map[idx]['chunk_text']}\n"
                f"Tags: {', '.join(self.vectorizer.document_map[idx].get('tags', []))}\n"
                for idx in indices[0] if idx in self.vectorizer.document_map
            ])
            
            # Получаем ответ от Mistral
            response = self.mistral_client.get_insights(query, context)
            
            if response:
                self.current_state['insight'] = {
                    'type': content_type,
                    'content': response,
                    'query': query
                }
                self.content_display.setText(response)
                self.status_label.setText(f"✨ New {content_type} generated. Please review and choose Save or Skip.")
                self.confirm_buttons.show()
            else:
                self.content_display.setText("❌ Failed to generate content.\nPlease try again.")
                self.status_label.setText("Generation failed")
                
            self.set_processing_state(False)
            
        except Exception as e:
            self.content_display.setText(f"⚠️ Error occurred: {str(e)}\nPlease try again.")
            self.status_label.setText("Error occurred")
            self.set_processing_state(False)

    def save_current_content(self):
        """Сохраняет текущий контент"""
        if not self.current_state['insight'] or self.current_state['processing']:
            return
            
        try:
            self.set_processing_state(True)
            self.save_btn.setText("💾 Saving...")
            
            content = self.current_state['insight']['content']
            content_type = self.current_state['insight']['type']
            
            # Добавляем базовые теги в зависимости от типа
            if content_type == 'initial':
                content += "\n[[initial-analysis]] [[ai-generated]]"
                prefix = "ai_initial_analysis"
            elif content_type == 'task':
                content += "\n[[task]] [[ai-generated]]"
                prefix = "ai_task"
            else:  # insight
                content = f"[[insight]]\n{content}\n[[insight]] [[ai-generated]]"
                prefix = "ai_insight"
            
            # Используем путь из конфига и добавляем подпапку _AI_Recommendations
            base_path = Path(self.config.path) / '_AI_Recommendations'
            base_path.mkdir(parents=True, exist_ok=True)
            
            # Формируем имя файла
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{prefix}_{timestamp}.md"
            
            # Сохраняем файл
            with open(base_path / filename, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.status_label.setText(f"✅ Successfully saved as {filename}")
            self.stats['insights_saved'] += 1
            self.update_stats_display()
            
            # Очищаем состояние
            self.clear_current_insight()
            
        except Exception as e:
            self.logger.error(f"Error saving content: {e}")
            self.status_label.setText(f"❌ Error: {str(e)}")
        finally:
            self.save_btn.setText("✅ Save")
            self.set_processing_state(False)

    def skip_current_content(self):
        """Пропускает текущий контент с сохранением важных данных"""
        if not self.current_state['insight'] or self.current_state['processing']:
            return
        
        try:
            self.set_processing_state(True)
            
            # Логируем действие
            content_type = self.current_state['insight']['type']
            self.logger.info(f"Skipping {content_type} content")
            
            # Очищаем только текущий инсайт
            self.clear_current_insight()
            self.status_label.setText("✓ Content skipped")
            
        except Exception as e:
            self.logger.error(f"Error while skipping content: {e}")
            self.status_label.setText(f"❌ Error while skipping: {str(e)}")
        finally:
            self.set_processing_state(False)

    def clear_current_insight(self):
        """Очищает только текущий инсайт, сохраняя остальное состояние"""
        self.logger.info("Clearing current insight")
        
        # Логируем состояние ДО очистки
        has_context = bool(self.current_state.get('context'))
        has_query = bool(self.current_state.get('last_query'))
        self.logger.info(f"Before clear - Context: {has_context}, Query: {has_query}")
        
        # Сохраняем важные данные
        context = self.current_state.get('context')
        last_query = self.current_state.get('last_query')
        
        # Обновляем только необходимые поля
        self.current_state.update({
            'insight': None,
            'context': context,
            'last_query': last_query
        })
        
        # Логируем состояние ПОСЛЕ очистки
        has_context_after = bool(self.current_state.get('context'))
        has_query_after = bool(self.current_state.get('last_query'))
        self.logger.info(
            f"After clear - Context preserved: {has_context_after}, "
            f"Query preserved: {has_query_after}"
        )
        
        # Обновляем UI
        self.content_display.setText("Ready for new generation.")
        self.confirm_buttons.hide()
        self.status_label.setText("Ready for next generation")

    def confirm_exit(self):
        """Подтверждение выхода"""
        if self.current_state['insight']:
            reply = QMessageBox.question(
                self,
                "Confirm Exit",
                "You have unsaved content. Exit anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.No:
                return
        QApplication.quit()

    def add_message(self, sender: str, content: str):
        """Добавляет сообщение в чат и обновляет отображение"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {sender}:\n{content}\n"
        
        # Добавляем в текстовое поле
        self.chat_display.append(formatted_message)
        
        # Прокручиваем к последнему сообщению
        scrollbar = self.chat_display.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def show_initial_analysis(self, analysis: str):
        """Показывает первичный анализ vault с возможностью сохранения"""
        print("Showing initial analysis...")
        
        # Форматируем анализ для лучшего отображения
        formatted_analysis = (
            "🔍 Initial Vault Analysis\n"
            "=" * 50 + "\n\n"
            f"{analysis}\n\n"
            "=" * 50 + "\n\n"
            "Would you like to save this analysis?"
        )
        
        # Показываем анализ в главном окне
        self.content_display.clear()
        self.content_display.setText(formatted_analysis)
        
        # Важно: устанавливаем current_insight для сохранения
        self.current_state['insight'] = {
            'type': 'initial',
            'content': (f"# Initial Vault Analysis\n\n"
                       f"{analysis}\n\n"
                       "[[initial-analysis]] [[overview]] [[ai-generated]]"),
            'query': "Initial vault analysis and overview"
        }
        
        # Показываем кнопки Save/Skip
        self.confirm_buttons.show()
        self.status_label.setText("Initial vault analysis completed. Please review and choose to Save or Skip.")

    def save_initial_analysis(self, analysis: str):
        """Сохраняет первичный анализ как insight"""
        self.current_state['insight'] = {
            'type': 'initial',
            'content': f"# Initial Vault Analysis\n\n{analysis}\n\n[[initial-analysis]] [[overview]]",
            'query': "Initial vault analysis and overview"
        }
        self.save_current_content()

    def _set_ui_enabled(self, enabled: bool):
        """Блокирует/разблокирует UI элементы"""
        self.confirm_buttons.setEnabled(enabled)
        # Добавить другие элементы UI 

    def _validate_saved_file(self, filepath: Path, content: str) -> bool:
        """Проверяет корректность сохраненного файла"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                saved_content = f.read()
            return saved_content == content
        except Exception:
            return False

    def get_insights(self, query: str, context: str) -> str:
        try:
            return self.mistral_client.get_insights(query, context)
        except Exception:
            return False 