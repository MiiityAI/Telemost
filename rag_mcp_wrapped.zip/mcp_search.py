#!/usr/bin/env python3
"""
Улучшенный скрипт векторного поиска с поддержкой мультиязычности и точных совпадений.
Использование: python mcp_search.py --query "ваш запрос" [--index-dir ./index] [--top-k 5] [--threshold 0.3]
"""
import os
import json
import argparse
import numpy as np
import re
from typing import List, Dict, Any, Tuple

from config_loader import config_instance
from document_processor import DocumentProcessor
from mcp_wrapper import MCPWrapper

try:
    from langchain_community.vectorstores import FAISS
    from langchain_core.embeddings import Embeddings
except ImportError:
    print("Установите зависимости: pip install langchain faiss-cpu")
    import sys
    sys.exit(1)

def search_documents(query: str, index_dir: str = None, top_k: int = 5, threshold: float = None) -> Dict:
    """
    Выполняет гибридный поиск (семантический + точное соответствие) по запросу
    и возвращает наиболее релевантные результаты

    :param query: Поисковый запрос
    :param index_dir: Директория с индексом FAISS
    :param top_k: Количество результатов для возврата
    :param threshold: Минимальный порог релевантности (0-1)
    :return: Словарь с результатами поиска в формате MCP
    """
    # Получаем конфигурацию
    config = config_instance.get_config()
    
    # Если index_dir не задан, берем из конфигурации
    if index_dir is None:
        index_dir = config.get('output_dir', 'index')
    
    # Создаем процессор документов для эмбеддингов
    processor = DocumentProcessor(config)
    
    # Специализированный класс эмбеддингов с надежной нормализацией
    class RobustEmbeddings(Embeddings):
        def __init__(self, processor):
            self.processor = processor
            
        def embed_documents(self, texts):
            """Создает и нормализует эмбеддинги для списка текстов"""
            embeddings = self.processor.embed_documents(texts)
            # Нормализуем каждый вектор отдельно для стабильности
            normalized = []
            for emb in embeddings:
                norm = np.linalg.norm(emb)
                if norm > 0:
                    normalized.append([e / norm for e in emb])
                else:
                    normalized.append(emb)  # Если норма 0, оставляем как есть
            return normalized
            
        def embed_query(self, text):
            """Создает и нормализует эмбеддинг для запроса"""
            embedding = self.processor.embed_query(text)
            norm = np.linalg.norm(embedding)
            if norm > 0:
                return [e / norm for e in embedding]
            return embedding
    
    # Создаем объект эмбеддингов
    embeddings = RobustEmbeddings(processor)
    
    # Проверяем наличие файлов индекса
    if not os.path.exists(os.path.join(index_dir, "index.faiss")):
        raise ValueError(f"Файлы индекса FAISS не найдены в '{index_dir}'")
    
    # Загружаем индекс
    try:
        vector_store = FAISS.load_local(index_dir, embeddings, allow_dangerous_deserialization=True)
    except Exception as e:
        return {"error": f"Ошибка загрузки индекса: {str(e)}"}
    
    # Запрашиваем больше результатов для последующей фильтрации
    search_k = max(top_k * 3, 20)
    
    # Выполняем семантический поиск
    results = vector_store.similarity_search_with_score(query, k=search_k)
    
    # Преобразуем L2-расстояние в правильную меру сходства (гарантированно положительную)
    normalized_results = []
    for doc, score in results:
        # Гарантированно положительное значение релевантности от 0 до 1
        # Чем меньше расстояние, тем выше релевантность
        relevance = 1.0 / (1.0 + float(score))
        normalized_results.append((doc, relevance))
    
    # Добавляем бонус за точное соответствие запросу
    for i, (doc, score) in enumerate(normalized_results):
        # Ищем точное соответствие запросу (без учета регистра)
        if query.lower() in doc.page_content.lower():
            # Увеличиваем релевантность документов с точным совпадением
            bonus = 0.3  # Значительный бонус
            normalized_results[i] = (doc, min(score + bonus, 1.0))
    
    # Сортируем результаты по убыванию релевантности
    sorted_results = sorted(normalized_results, key=lambda x: x[1], reverse=True)
    
    # Если threshold не задан, показываем все результаты
    if threshold is None:
        effective_threshold = 0.0
    else:
        # Если threshold задан явно, используем его
        effective_threshold = threshold
    
    # Выводим диапазон релевантности для отладки
    score_range = [float(score) for _, score in sorted_results[:min(len(sorted_results), top_k)]]
    print(f"Диапазон релевантности: {score_range}")
    print(f"Эффективный порог: {effective_threshold}")
    
    # Группируем результаты по источникам с учетом порога релевантности
    sources = {}
    for doc, score in sorted_results:
        # Пропускаем результаты ниже порога
        if float(score) < effective_threshold:
            continue
            
        source = doc.metadata.get("source", "unknown")
        if source not in sources:
            sources[source] = {"text": "", "score": float(score)}
        sources[source]["text"] += doc.page_content + "\n\n"
        # Используем максимальную релевантность для источника
        sources[source]["score"] = max(sources[source]["score"], float(score))
    
    # Сортируем источники по релевантности
    sorted_sources = sorted(sources.items(), key=lambda x: x[1]["score"], reverse=True)
    # Ограничиваем количество источников при необходимости
    limited_sources = sorted_sources[:top_k]
    
    # Формируем комбинированный текст из результатов
    combined_text = ""
    for source, data in limited_sources:
        # Используем только имя файла для лучшей читаемости
        source_name = os.path.basename(source)
        # Форматируем с релевантностью
        combined_text += f"--- {source_name} (релевантность: {data['score']:.2f}) ---\n{data['text'].strip()}\n\n"
    
    # Создаем полный вывод в формате MCP
    mcp_data = MCPWrapper(index_dir).to_dict()
    output = {
        "query": query,
        "combined_text": combined_text.strip(),
        "sources": [src for src, _ in limited_sources],
        "source_texts": {src: data["text"] for src, data in limited_sources},
        "relevance_scores": {src: data["score"] for src, data in limited_sources},
        "result_count": len(sorted_results),
        "returned_count": len(limited_sources),
        "threshold": effective_threshold,
        **mcp_data
    }
    
    return output

def main():
    parser = argparse.ArgumentParser(description="Улучшенный векторный поиск с поддержкой мультиязычности")
    parser.add_argument("--query", type=str, required=True, help="Поисковый запрос")
    parser.add_argument("--index-dir", type=str, default=None, help="Директория с индексом (по умолчанию из конфигурации)")
    parser.add_argument("--top-k", type=int, default=5, help="Количество результатов (по умолчанию 5)")
    parser.add_argument("--threshold", type=float, default=None, help="Минимальный порог релевантности (0-1)")
    args = parser.parse_args()
    
    results = search_documents(args.query, args.index_dir, args.top_k, args.threshold)
    print(json.dumps(results, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()