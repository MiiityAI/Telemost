#!/usr/bin/env python3
"""
Script to split a large text file into overlapping chunks, generate embeddings using OpenAI,
and build a FAISS vector index.

Dependencies:
    pip install langchain faiss-cpu requests tiktoken

Usage:
    python build_index.py [--config ./config.yaml]
"""
import argparse
import os
import sys
try:
    import requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False
from typing import List, Dict, Any, Optional
from config_loader import config_instance

# Archive file extensions to skip
ARCHIVE_EXTENSIONS = ('.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.tgz')

# Импортируем зависимости на уровне модуля
try:
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain_community.vectorstores import FAISS
    from langchain_core.embeddings import Embeddings
except ImportError as e:
    print("Missing dependencies: please install with 'pip install langchain faiss-cpu requests tiktoken'")
    sys.exit(1)

def load_text(file_path: str) -> str:
    """Load text content from a file."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

class DocumentProcessor:
    """Класс для обработки документов: разделение, эмбеддинг и индексация"""
    
    def __init__(self, config=None):
        """
        Инициализация процессора документов
        
        :param config: Конфигурация для процессора
        """
        if config is None:
            config = config_instance.get_config()
            
        self.config = config
        
        # Инициализация текстового сплиттера
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.config['chunk_size'],
            chunk_overlap=self.config['chunk_overlap']
        )
        
        # URL API для embeddings
        self.base_url = self.config.get('api_base_url', 'http://localhost:1234').rstrip("/")
        self.embeddings_endpoint = f"{self.base_url}/v1/embeddings"
        self.model_name = self.config['model_name']
        
        # Кэшируем размерность эмбеддингов
        self._embedding_dimension = None
        
    def get_embedding_dimension(self) -> int:
        """
        Получает размерность эмбеддингов из модели
        
        :return: Размерность эмбеддингов
        """
        if self._embedding_dimension is not None:
            return self._embedding_dimension
            
        if not _HAS_REQUESTS:
            print("requests library not found, using default dimension")
            self._embedding_dimension = 384  # Дефолтное значение
            return self._embedding_dimension
            
        try:
            # Делаем тестовый запрос с одним словом
            response = requests.post(
                self.embeddings_endpoint,
                json={
                    "model": self.model_name,
                    "input": ["test"]
                },
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                test_embedding = response.json().get('data', [])[0]['embedding']
                self._embedding_dimension = len(test_embedding)
                print(f"Определена размерность эмбеддингов: {self._embedding_dimension}")
            else:
                print(f"Ошибка при определении размерности: {response.status_code}")
                self._embedding_dimension = 384  # Дефолтное значение
                
        except Exception as e:
            print(f"Ошибка при определении размерности эмбеддингов: {str(e)}")
            self._embedding_dimension = 384  # Дефолтное значение
            
        return self._embedding_dimension
    
    def split_text(self, text: str) -> List[str]:
        """
        Разделяет текст на чанки
        
        :param text: Исходный текст
        :return: Список чанков
        """
        return self.splitter.split_text(text)
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Создает эмбединги для списка текстов
        
        :param texts: Список текстов для эмбеддинга
        :return: Список векторов эмбеддингов
        """
        if not texts:
            return []
            
        dim = self.get_embedding_dimension()
            
        if not _HAS_REQUESTS:
            print("requests library not found, returning zero embeddings")
            return [[0.0] * dim for _ in texts]
        try:
            response = requests.post(
                self.embeddings_endpoint,
                json={
                    "model": self.model_name,
                    "input": texts
                },
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            if response.status_code == 200:
                embeddings = []
                for item in response.json().get('data', []):
                    embeddings.append(item['embedding'])
                return embeddings
            else:
                error_msg = f"Ошибка {response.status_code}: {response.text}"
                print(error_msg)
                # Возвращаем пустые эмбеддинги в случае ошибки
                return [[0.0] * dim] * len(texts)
        except Exception as e:
            print(f"Ошибка подключения к серверу эмбеддингов: {str(e)}")
            return [[0.0] * dim] * len(texts)
            
    def embed_query(self, text: str) -> List[float]:
        """
        Создает эмбеддинг для одного текста запроса
        
        :param text: Текст для эмбеддинга
        :return: Вектор эмбеддинга
        """
        result = self.embed_documents([text])
        dim = self.get_embedding_dimension()
        return result[0] if result else [0.0] * dim
        
    def process_document(self, file_path: str, output_dir: str) -> None:
        """
        Полный пайплайн обработки документа: разделение, эмбеддинг и индексация
        
        :param file_path: Путь к файлу документа
        :param output_dir: Путь для сохранения индекса
        """
        # Загружаем текст из файла
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
            
        # Разделяем текст на чанки
        chunks = self.split_text(text)
        print(f"Разделено на {len(chunks)} чанков")
        
        # Создаем векторное хранилище
        print("Генерация эмбеддингов и создание индекса...")
        
        # Создаем документы с метаданными
        from langchain.schema import Document
        documents = [Document(page_content=chunk, metadata={"source": file_path}) for chunk in chunks]
        
        # Подкласс для эмбеддингов
        class _DocumentProcessorEmbeddings(Embeddings):
            def __init__(self, processor):
                self.processor = processor
                
            def embed_documents(self, texts):
                return self.processor.embed_documents(texts)
                
            def embed_query(self, text):
                return self.processor.embed_query(text)
        
        embeddings_obj = _DocumentProcessorEmbeddings(self)
        
        # Используем from_documents вместо from_texts для сохранения метаданных
        vectorstore = FAISS.from_documents(documents=documents, embedding=embeddings_obj)
        
        # Сохраняем индекс
        os.makedirs(output_dir, exist_ok=True)
        vectorstore.save_local(output_dir)
        print(f"Индекс сохранен в '{output_dir}'")

def main():
    parser = argparse.ArgumentParser(
        description="Split a text file into overlapping chunks, embed them, and build a FAISS index."
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="Path to the config file (default: config.yaml)."
    )
    args = parser.parse_args()
    
    config = config_instance.get_config()
    source_path = config['source_path']
    output_dir = config['output_dir']
    
    # Загружаем текст
    text = load_text(source_path)
    
    # Создаем и используем процессор документов
    processor = DocumentProcessor(config)
    processor.process_document(text, output_dir)
    # Generate MCP-compatible JSON output
    from mcp_wrapper import MCPWrapper
    wrapper = MCPWrapper(output_dir, source_path)
    wrapper.print()

if __name__ == "__main__":
    main()
