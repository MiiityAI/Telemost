import requests
import logging
from typing import Dict, Optional
from datetime import datetime
from pathlib import Path
import argparse
import sys
import re
import json
import time

class MistralClient:
    def __init__(self, api_url: str):
        self.api_url = api_url
        self.session = requests.Session()
        self.timeout = 60
        self.max_retries = 3  # Возвращаем это!
        
        # Настраиваем логирование
        self.logger = logging.getLogger(__name__)
        self._setup_logging()

    def _setup_logging(self):
        """Настройка логирования в файл"""
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = log_dir / f"mistral_client_{timestamp}.log"
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        self.logger.addHandler(file_handler)
        self.logger.setLevel(logging.DEBUG)

    def _create_chat_messages(self, query: str, context: str, is_insight: bool = True) -> list:
        """Создает сообщения для чата"""
        system_message = "You are a helpful AI assistant that analyzes documents and provides insights or tasks."
        task_type = "an insightful observation" if is_insight else "a specific, actionable task"
        
        # Формирование запроса
        user_prompt = f"""Based on the following context from the vault, generate {task_type}.

Context:
{context}

Query:
{query}

Please provide a clear and concise response that could be valuable for the vault owner."""
        
        messages = [
            {"role": "assistant", "content": system_message},
            {"role": "user", "content": user_prompt}
        ]
        
        # Если общий текст слишком большой, обрежем контекст
        total_length = sum(len(m['content']) for m in messages)
        if total_length > 1000:  # условный лимит — можно корректировать
            self.logger.warning("Request payload too long, trimming context.")
            # Усечём контекст до первых 2000 символов
            context = context[:2000] + "...[truncated]..."
            messages[1]["content"] = f"Context:\n{context}\n\nQuery:\n{query}"
        
        return messages

    def _make_request(self, messages: list) -> Optional[str]:
        """Делает запрос к API с повторными попытками"""
        for attempt in range(self.max_retries):
            try:
                self.logger.info(f"Making API request (attempt {attempt + 1}/{self.max_retries})")
                
                # Логируем полный payload запроса
                payload = {
                    "messages": messages,
                    "temperature": 0.7,
                    "max_tokens": 500
                }
                self.logger.info(f"Request payload: {json.dumps(payload, indent=2)}")
                self.logger.info(f"Request URL: {self.api_url}")
                
                response = self.session.post(
                    self.api_url,
                    json=payload,
                    timeout=self.timeout
                )
                
                # Логируем ответ
                self.logger.info(f"Response status code: {response.status_code}")
                self.logger.info(f"Response headers: {dict(response.headers)}")
                
                if response.status_code != 200:
                    self.logger.error(f"Error response: {response.text}")
                    raise requests.exceptions.RequestException(
                        f"API returned status {response.status_code}: {response.text}"
                    )
                
                result = response.json()
                self.logger.info(f"Parsed JSON response: {json.dumps(result, indent=2)}")
                
                if 'choices' in result and len(result['choices']) > 0:
                    return result['choices'][0]['message']['content']
                else:
                    self.logger.error(f"Unexpected API response format: {result}")
                    
            except requests.Timeout:
                self.logger.error(f"Request timeout (attempt {attempt + 1})")
            except requests.RequestException as e:
                self.logger.error(f"Request failed (attempt {attempt + 1}): {e}")
            except Exception as e:
                self.logger.error(f"Unexpected error (attempt {attempt + 1}): {e}")
                self.logger.exception("Full traceback:")
                
            if attempt < self.max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
                
        return None

    def get_insights(self, query: str, context: str) -> Optional[str]:
        """Получает инсайты от API"""
        try:
            messages = self._create_chat_messages(query, context, is_insight=True)
            return self._make_request(messages)
        except Exception as e:
            self.logger.error(f"Error getting insights: {e}")
            return None

    def get_tasks(self, query: str, context: str) -> Optional[str]:
        """Получает задачи от API"""
        try:
            messages = self._create_chat_messages(query, context, is_insight=False)
            return self._make_request(messages)
        except Exception as e:
            self.logger.error(f"Error getting tasks: {e}")
            return None

    def analyze_vault_completion(self, stats: dict) -> Optional[int]:
        """Анализирует заполненность vault"""
        try:
            query = (
                "You are a critical analyst of knowledge bases. "
                "Based on these vault statistics, estimate the completion percentage (0-100). "
                "Consider:\n"
                "- Quality and quantity of connections between notes\n"
                "- Coverage of key topics\n"
                "- Depth of analysis\n"
                "- Use of tags and categorization\n"
                "Be conservative in your estimate, as there's always room for improvement. "
                "Return only a number between 0-100.\n\n"
                f"Stats:\n{json.dumps(stats, indent=2)}"
            )
            
            response = self.get_insights(query, "")
            if not response:
                return None
                
            try:
                # Извлекаем число из ответа
                completion = int(''.join(filter(str.isdigit, response)))
                return min(100, max(0, completion))  # Ограничиваем значением 0-100
            except ValueError:
                self.logger.error(f"Could not extract number from response: {response}")
                return None
                
        except Exception as e:
            self.logger.error(f"Failed to analyze vault completion: {e}")
            return None

    def get_chat_reply(self, messages: list, vectorizer=None) -> Optional[str]:
        """Отправляет список сообщений к API с учетом контекста из vault'а"""
        try:
            self.logger.info("=== Chat Reply Request ===")
            
            # Если есть vectorizer, добавляем контекст из vault'а
            if vectorizer and messages:
                self.logger.info("Vectorizer provided, searching for context")
                user_messages = [m for m in messages if m['role'] == 'user']
                self.logger.info(f"Found {len(user_messages)} user messages")
                
                if user_messages:
                    user_query = user_messages[-1]['content']
                    self.logger.info(f"Last user query: {user_query}")
                    
                    context = self._get_relevant_context(vectorizer, user_query)
                    self.logger.info(f"Retrieved context length: {len(context)}")
                    
                    if context:
                        self.logger.info("Adding context to messages")
                        context_messages = [
                            {"role": "assistant", "content": "You are a helpful AI assistant analyzing a knowledge vault. "
                                                        "Use the provided context to answer questions accurately."},
                            {"role": "assistant", "content": f"Relevant vault context:\n{context}"}
                        ]
                        messages = context_messages + messages
                    else:
                        self.logger.warning("No context retrieved from vectorizer")
            else:
                self.logger.info("No vectorizer provided or empty messages")
            
            self.logger.info(f"Sending {len(messages)} messages to API")
            response = self._make_request(messages)
            return response
            
        except Exception as e:
            self.logger.error(f"Error in chat reply: {str(e)}")
            self.logger.exception("Full traceback:")
            return None

    def _get_relevant_context(self, vectorizer, query: str) -> str:
        """Получает релевантный контекст из vault"""
        try:
            self.logger.info(f"Getting context for query: {query}")
            
            # Векторизуем запрос
            query_vector = vectorizer.model.encode([query])
            distances, indices = vectorizer.index.search(query_vector, k=5)
            
            # Получаем список UUID по порядку добавления
            ordered_uuids = list(vectorizer.document_map.keys())
            
            self.logger.info(f"Found {len(indices[0])} relevant documents")
            self.logger.debug(f"Document indices: {indices[0].tolist()}")
            
            context_parts = []
            for idx in indices[0]:
                if 0 <= idx < len(ordered_uuids):  # Проверяем, что индекс в пределах списка
                    uuid = ordered_uuids[idx]  # Получаем UUID по индексу
                    if uuid in vectorizer.document_map:
                        doc = vectorizer.document_map[uuid]
                        context_parts.append(
                            f"Document: {doc['file_path']}\n"
                            f"Content: {doc['chunk_text']}\n"
                            f"Tags: {', '.join(doc.get('tags', []))}"
                        )
                        self.logger.debug(f"Added document {uuid} to context")
                    else:
                        self.logger.warning(f"UUID {uuid} not found in document_map")
                else:
                    self.logger.warning(f"Index {idx} out of range for ordered_uuids")
            
            context = "\n---\n".join(context_parts)
            self.logger.info(f"Created context with {len(context)} characters")
            return context
            
        except Exception as e:
            self.logger.error(f"Error getting context: {str(e)}")
            self.logger.exception("Full traceback:")
            return ""

def test_request():
    """Выполняет тестовый запрос к Mistral API"""
    client = MistralClient("http://localhost:1234/v1/chat/completions")
    
    test_query = "Hello, world! This is a test message."
    test_context = "This is a test context for the Mistral API."
    
    print("\n" + "="*50)
    print("🔄 Sending test request to Mistral API")
    print("="*50)
    print(f"Query: {test_query}")
    print(f"Context: {test_context}")
    print("-"*50)
    
    response = client.get_insights(test_query, test_context)
    
    print("\n📝 Response from Mistral:")
    print("-"*50)
    print(response if response else "No response received")
    print("="*50)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Mistral API Client')
    parser.add_argument('--test', action='store_true', help='Run a test request to Mistral API')
    
    args = parser.parse_args()
    
    if args.test:
        test_request()
    else:
        print("Use --test flag to run a test request")
        sys.exit(1) 