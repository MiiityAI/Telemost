#!/usr/bin/env python3
"""
MCP (Model-Chunks-Predictor) Wrapper для стандартизированного вывода данных индекса FAISS.

Этот модуль предоставляет обертку для работы с индексами FAISS и вывода
необходимой информации о них в стандартизированном формате.
"""
import os
import json
from typing import Dict, Optional, Any

class MCPWrapper:
    """
    Класс-обертка для работы с индексом FAISS и вывода информации в формате MCP.
    Предоставляет методы для получения и форматирования метаданных индекса.
    """
    
    def __init__(self, index_dir: str, source_path: Optional[str] = None):
        """
        Инициализация обертки MCP.
        
        :param index_dir: Директория с индексом FAISS
        :param source_path: Путь к исходным документам (опционально)
        """
        self.index_dir = index_dir
        self.source_path = source_path
        
        # Проверяем наличие индекса FAISS
        self.index_file = os.path.join(index_dir, "index.faiss")
        self.embeddings_file = os.path.join(index_dir, "index.pkl")
        
        if not os.path.exists(self.index_file) or not os.path.exists(self.embeddings_file):
            raise ValueError(f"FAISS файлы индекса не найдены в '{index_dir}'")
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Возвращает словарь с информацией об индексе в формате MCP.
        
        :return: Словарь с данными индекса
        """
        return {
            "embeddings_file": self.embeddings_file,
            "index_file": self.index_file,
            # Дополнительная метаинформация может быть добавлена здесь
        }
    
    def print(self) -> None:
        """
        Выводит информацию об индексе в формате JSON.
        """
        output = self.to_dict()
        
        # Если есть путь к исходным документам, добавляем эту информацию
        if self.source_path:
            output["source_path"] = self.source_path
            
            # Если исходный путь - файл, можно добавить размер файла
            if os.path.isfile(self.source_path):
                output["file_size"] = os.path.getsize(self.source_path)
                
            # Если исходный путь - директория, можно добавить количество файлов
            elif os.path.isdir(self.source_path):
                file_count = 0
                for _, _, files in os.walk(self.source_path):
                    file_count += len(files)
                output["file_count"] = file_count
        
        # Выводим в формате JSON
        print(json.dumps(output, indent=2, ensure_ascii=False))
    
    def get_index_stats(self) -> Dict[str, Any]:
        """
        Возвращает статистику индекса FAISS.
        
        :return: Словарь со статистикой индекса
        """
        stats = {
            "index_size": os.path.getsize(self.index_file),
            "embeddings_size": os.path.getsize(self.embeddings_file),
            "total_size": os.path.getsize(self.index_file) + os.path.getsize(self.embeddings_file)
        }
        return stats

if __name__ == "__main__":
    # Пример использования
    import argparse
    
    parser = argparse.ArgumentParser(description="MCP обертка для индекса FAISS")
    parser.add_argument("--index-dir", "-i", type=str, required=True, help="Директория с индексом")
    parser.add_argument("--source", "-s", type=str, help="Путь к исходным документам")
    
    args = parser.parse_args()
    
    wrapper = MCPWrapper(args.index_dir, args.source)
    wrapper.print()
