from typing import List
import logging

class TextChunker:
    def __init__(self, chunk_size: int, overlap: int):
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.logger = logging.getLogger(__name__)

    def chunk_text(self, text: str) -> List[str]:
        chunks = []
        start = 0
        text_len = len(text)
        
        while start < text_len:
            end = start + self.chunk_size
            
            if end < text_len:
                # Find the nearest sentence end
                while end < text_len and text[end] not in '.!?':
                    end += 1
                if end < text_len:
                    end += 1
            
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            start = end - self.overlap
            
        return chunks 