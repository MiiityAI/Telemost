import logging
import numpy as np
from typing import List, Dict, Any
from .vectorizer import DocumentVectorizer
import uuid
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

class BatchProcessor:
    def __init__(self, vectorizer, batch_size=10):
        self.vectorizer = vectorizer
        self.batch_size = batch_size
        self.logger = logging.getLogger(__name__)
        self.current_batch = {}
        self.processed_count = 0

    def add_to_batch(self, chunk: str, metadata: dict):
        """Добавляет чанк с метаданными в текущий батч"""
        try:
            doc_id = str(uuid.uuid4())  # Генерируем уникальный ID
            document = {
                'chunk_text': chunk,
                'file_path': metadata.get('file_path', ''),
                'tags': metadata.get('tags', []),
                'created_at': datetime.now().isoformat()
            }
            
            self.current_batch[doc_id] = document
            self.logger.debug(f"Added document {doc_id} to batch")
            
            if len(self.current_batch) >= self.batch_size:
                self.process_batch(self.current_batch)
                self.current_batch = {}
                
        except Exception as e:
            self.logger.error(f"Error adding to batch: {e}")

    def process_batch(self, documents: dict):
        """Обрабатывает батч документов"""
        if not documents:
            return
            
        try:
            self.logger.info(f"Processing batch of {len(documents)} documents")
            self.vectorizer.vectorize_documents(documents)
            self.processed_count += len(documents)
            self.logger.info(f"Total documents processed: {self.processed_count}")
            
        except Exception as e:
            self.logger.error(f"Error processing batch: {e}")
            # Пробуем обработать документы по одному
            for doc_id, doc in documents.items():
                try:
                    self.vectorizer.vectorize_documents({doc_id: doc})
                    self.processed_count += 1
                except Exception as inner_e:
                    self.logger.error(f"Failed to process document {doc_id}: {inner_e}")

    def process_batch_parallel(self, documents: dict):
        """Обрабатывает батч документов параллельно"""
        if not documents:
            return
        try:
            self.logger.info(f"Processing batch of {len(documents)} documents in parallel")
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = []
                for doc_id, doc in documents.items():
                    futures.append(executor.submit(self.vectorizer.vectorize_documents, {doc_id: doc}))
                for future in futures:
                    try:
                        future.result()
                        self.processed_count += 1
                    except Exception as inner_e:
                        self.logger.error(f"Failed to process document in parallel: {inner_e}")
            self.logger.info(f"Total documents processed: {self.processed_count}")
        except Exception as e:
            self.logger.error(f"Error processing batch in parallel: {e}")

    def finalize(self):
        """Обрабатывает оставшиеся документы"""
        if self.current_batch:
            self.logger.info(f"Processing final batch of {len(self.current_batch)} documents")
            self.process_batch(self.current_batch)
            self.current_batch = {}
            
        if self.processed_count == 0:
            self.logger.warning("No documents were processed in this session")
        else:
            self.logger.info(f"Finished processing {self.processed_count} documents in total")

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Обработка оставшихся документов при выходе из контекста"""
        if self.current_batch:
            self.logger.info(f"Processing final batch of {len(self.current_batch)} documents")
            self.finalize()
        else:
            self.logger.warning("No documents were processed in this session")
    
    def _process_current_batch(self) -> None:
        self.process_batch(self.current_batch) 