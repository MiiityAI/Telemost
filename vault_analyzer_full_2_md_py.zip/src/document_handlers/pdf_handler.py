import fitz
import logging
from pathlib import Path
from typing import Optional
import re

class PDFHandler:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.stats = {
            'processed_pdfs': 0,
            'failed_pdfs': 0,
            'total_pages': 0
        }

    def extract_text(self, pdf_path: Path) -> Optional[str]:
        try:
            self.logger.info(f"Processing PDF: {pdf_path}")
            doc = fitz.open(pdf_path)
            
            # Собираем статистику
            page_count = len(doc)
            self.stats['total_pages'] += page_count
            
            text = ""
            for i, page in enumerate(doc):
                text += page.get_text() + "\n"
                if (i + 1) % 10 == 0:  # Логируем каждые 10 страниц
                    self.logger.debug(f"Processed {i + 1}/{page_count} pages")
            
            doc.close()
            self.stats['processed_pdfs'] += 1
            
            self.logger.info(
                f"Successfully extracted text from {pdf_path}:\n"
                f"  Pages: {page_count}\n"
                f"  Text length: {len(text)} characters"
            )
            
            return re.sub(r'\s+', ' ', text).strip()
            
        except Exception as e:
            self.stats['failed_pdfs'] += 1
            self.logger.error(f"Error processing PDF {pdf_path}: {e}")
            return None 