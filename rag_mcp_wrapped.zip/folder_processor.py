import os
import argparse
from config_loader import config_instance
from document_processor import DocumentProcessor
from mcp_wrapper import MCPWrapper
from langchain.schema import Document
from langchain_community.vectorstores import FAISS
from langchain_core.embeddings import Embeddings

# Список шаблонов и имен для исключения (бинарные и скрытые файлы)
excluded_items = [
    "__pycache__",
    "*.zip", "*.doc*", "*.xls*", "*.ods", "*.7z", "*.rar", "*.tar*",
    "*.gz", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.pdf", "*.exe",
    "*.dll", "*.so", "*.bin", "*.pyc", "*.mp3", "*.mp4", "*.avi"
]

def process_folder(folder_path: str, output_dir: str):
    """
    Process all text files in a folder: split into chunks, embed, build FAISS index, and output MCP JSON.

    :param folder_path: Path to the folder to index
    :param output_dir: Directory to save the FAISS index
    """
    config = config_instance.get_config()
    processor = DocumentProcessor(config)
    documents = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            full_path = os.path.join(root, file)
            # Skip hidden and excluded files
            if file.startswith('.') or any(file.lower().endswith(ext.strip('*')) for ext in excluded_items):
                print(f"Пропускаем файл: {file}")
                continue
            # Try to read as text
            try:
                with open(full_path, 'r', encoding='utf-8') as f:
                    text = f.read()
            except (UnicodeDecodeError, IOError):
                print(f"Пропускаем бинарный файл: {file}")
                continue
            print(f"Разбиваем файл на чанки: {file}")
            chunks = processor.split_text(text)
            print(f"Чанков: {len(chunks)}")
            for chunk in chunks:
                documents.append(Document(page_content=chunk, metadata={"source": full_path}))
    if not documents:
        print("Нет текстовых документов для индексирования")
        return
    class ProcessorEmbeddings(Embeddings):
        def __init__(self, processor):
            self.processor = processor
        def embed_documents(self, texts):
            return self.processor.embed_documents(texts)
        def embed_query(self, text):
            return self.processor.embed_query(text)
    embeddings = ProcessorEmbeddings(processor)
    print("Формирование FAISS индекса...")
    vectorstore = FAISS.from_documents(documents=documents, embedding=embeddings)
    os.makedirs(output_dir, exist_ok=True)
    vectorstore.save_local(output_dir)
    print(f"Индекс сохранен в '{output_dir}'")
    wrapper = MCPWrapper(output_dir, folder_path)
    wrapper.print()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Index all text files in a folder into FAISS and output MCP JSON")
    parser.add_argument("--folder", "-f", type=str, help="Folder path to index")
    parser.add_argument("--output-dir", "-o", type=str, help="Directory to save FAISS index")
    args = parser.parse_args()
    cfg = config_instance.get_config()
    folder = args.folder or cfg.get("source_path", ".")
    out = args.output_dir or cfg.get("output_dir", "index")
    process_folder(folder, out)