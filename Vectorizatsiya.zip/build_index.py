#!/usr/bin/env python3
"""
Script to split a large text file into overlapping chunks, generate embeddings using OpenAI,
and build a FAISS vector index.

Dependencies:
    pip install langchain faiss-cpu requests tiktoken

Usage:
    python build_index.py [--config ./config.yaml]
"""
import argparse
import os
import sys
import requests
from typing import List, Dict, Any, Optional
from config_loader import config_instance

# Импортируем зависимости на уровне модуля
try:
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain.vectorstores import FAISS
except ImportError as e:
    print("Missing dependencies: please install with 'pip install langchain faiss-cpu requests tiktoken'")
    sys.exit(1)

def load_text(file_path: str) -> str:
    """Load text content from a file."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

class DocumentProcessor:
    """Класс для обработки документов: разделение, эмбеддинг и индексация"""
    
    def __init__(self, config=None):
        """
        Инициализация процессора документов
        
        :param config: Конфигурация для процессора
        """
        if config is None:
            config = config_instance.get_config()
            
        self.config = config
        
        # Инициализация текстового сплиттера
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=config['chunk_size'],
            chunk_overlap=config['chunk_overlap']
        )
        
        # URL API для embeddings
        self.base_url = config.get('api_base_url', 'http://localhost:1234').rstrip("/")
        self.embeddings_endpoint = f"{self.base_url}/v1/embeddings"
        self.model_name = config['model_name']
        
    def split_text(self, text: str) -> List[str]:
        """
        Разделяет текст на чанки
        
        :param text: Исходный текст
        :return: Список чанков
        """
        return self.splitter.split_text(text)
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Создает эмбединги для списка текстов
        
        :param texts: Список текстов для эмбеддинга
        :return: Список векторов эмбеддингов
        """
        if not texts:
            return []
            
        try:
            response = requests.post(
                self.embeddings_endpoint,
                json={
                    "model": self.model_name,
                    "input": texts
                },
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            
            if response.status_code == 200:
                embeddings = []
                for item in response.json().get('data', []):
                    embeddings.append(item['embedding'])
                return embeddings
            else:
                error_msg = f"Ошибка {response.status_code}: {response.text}"
                print(error_msg)
                # Возвращаем пустые эмбеддинги в случае ошибки
                return [[0.0] * 384] * len(texts)
                
        except requests.exceptions.RequestException as e:
            print(f"Ошибка подключения к серверу эмбеддингов: {str(e)}")
            return [[0.0] * 384] * len(texts)
            
    def embed_query(self, text: str) -> List[float]:
        """
        Создает эмбеддинг для одного текста запроса
        
        :param text: Текст для эмбеддинга
        :return: Вектор эмбеддинга
        """
        result = self.embed_documents([text])
        return result[0] if result else [0.0] * 384
        
    def process_document(self, text: str, output_dir: str) -> None:
        """
        Полный пайплайн обработки документа: разделение, эмбеддинг и индексация
        
        :param text: Исходный текст
        :param output_dir: Путь для сохранения индекса
        """
        # Разделяем текст на чанки
        chunks = self.split_text(text)
        print(f"Разделено на {len(chunks)} чанков")
        
        # Создаем векторное хранилище
        print("Генерация эмбеддингов и создание индекса...")
        
        # Используем себя как объект эмбеддингов для совместимости с FAISS
        # Через создание прокси-класса с нужными методами
        embeddings_obj = type('Embeddings', (), {
            'embed_documents': self.embed_documents,
            'embed_query': self.embed_query
        })()
        
        vectorstore = FAISS.from_texts(texts=chunks, embedding=embeddings_obj)
        
        # Сохраняем индекс
        os.makedirs(output_dir, exist_ok=True)
        vectorstore.save_local(output_dir)
        print(f"Индекс сохранен в '{output_dir}'")

def main():
    parser = argparse.ArgumentParser(
        description="Split a text file into overlapping chunks, embed them, and build a FAISS index."
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="Path to the config file (default: config.yaml)."
    )
    args = parser.parse_args()
    
    config = config_instance.get_config()
    source_path = config['source_path']
    output_dir = config['output_dir']
    
    # Загружаем текст
    text = load_text(source_path)
    
    # Создаем и используем процессор документов
    processor = DocumentProcessor(config)
    processor.process_document(text, output_dir)

if __name__ == "__main__":
    main()