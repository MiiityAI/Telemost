import os
import re
try:
    import yaml
    _HAS_YAML = True
except ImportError:
    _HAS_YAML = False

def _load_config():
    """
    Load configuration from YAML file or simple key:value pairs if PyYAML is unavailable.
    """
    path = 'config.yaml'
    if _HAS_YAML:
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    # Fallback simple parser (lines of 'key: value')
    config = {}
    with open(path, 'r', encoding='utf-8') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('#') or ':' not in line:
                continue
            key, val = line.split(':', 1)
            key = key.strip()
            val = val.strip()
            # Strip surrounding quotes
            if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
                config[key] = val[1:-1]
            # Integer
            elif re.fullmatch(r"\d+", val):
                config[key] = int(val)
            else:
                config[key] = val
    return config

class ConfigLoader:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigLoader, cls).__new__(cls)
            # Load config via PyYAML or fallback parser
            cfg = _load_config()
            # Handle expressions like key + "/suffix"
            out = cfg.get('output_dir')
            if isinstance(out, str) and '+' in out:
                parts = out.split('+', 1)
                key0 = parts[0].strip()
                if key0 in cfg:
                    base = cfg[key0]
                    # strip quotes from suffix
                    suffix = parts[1].strip().strip('"').strip("'")
                    cfg['output_dir'] = base + suffix
            cls._instance.config = cfg
        return cls._instance
    
    def get_config(self):
        return self.config

# Создаем единственный экземпляр для импорта из других модулей
config_instance = ConfigLoader()

print(config_instance.get_config())