import os
import yaml

class ConfigLoader:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigLoader, cls).__new__(cls)
            with open('config.yaml', 'r') as f:
                cls._instance.config = yaml.safe_load(f)
            
            # Обработка строковых выражений
            if isinstance(cls._instance.config['output_dir'], str) and '+' in cls._instance.config['output_dir']:
                parts = cls._instance.config['output_dir'].split('+')
                if parts[0].strip() in cls._instance.config:
                    base_path = cls._instance.config[parts[0].strip()]
                    suffix = parts[1].strip().replace('"', '').replace("'", '')
                    cls._instance.config['output_dir'] = base_path + suffix
                    
        return cls._instance
    
    def get_config(self):
        return self.config

# Создаем единственный экземпляр для импорта из других модулей
config_instance = ConfigLoader()

print(config_instance.get_config())