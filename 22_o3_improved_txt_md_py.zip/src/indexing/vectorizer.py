from sentence_transformers import SentenceTransformer
import numpy as np
import faiss
import logging
from typing import List, Dict, Optional, Set
from pathlib import Path
import pickle
import re
from functools import lru_cache
import json
import hashlib
from datetime import datetime

class DocumentVectorizer:
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.model = SentenceTransformer(self.config.model_name)
        
        # Пути для кэша
        self.cache_dir = Path(self.config.path) / '.vector_cache'
        self.cache_dir.mkdir(exist_ok=True)
        
        # Важно: храним маппинг индексов к document_ids
        self.index_to_id_map = []  # Список, где индекс = позиция в FAISS, значение = document_id
        self.document_map = {}      # Словарь document_id -> document
        self.index = None
        
        # Загружаем состояние
        self._load_state()
        
    def _load_state(self):
        """Загружает состояние из файлов"""
        try:
            # Загружаем документы
            docs_path = self.cache_dir / 'documents.json'
            if docs_path.exists():
                with open(docs_path, 'r', encoding='utf-8') as f:
                    self.document_map = json.load(f)
                    
            # Загружаем маппинг индексов
            map_path = self.cache_dir / 'index_map.json'
            if map_path.exists():
                with open(map_path, 'r', encoding='utf-8') as f:
                    self.index_to_id_map = json.load(f)
                    
            # Загружаем FAISS индекс
            index_path = self.cache_dir / 'faiss.index'
            if index_path.exists():
                self.index = faiss.read_index(str(index_path))
                
            if not self.verify_integrity():
                self.logger.warning("Integrity check failed on load, rebuilding...")
                self._rebuild_all()
                
        except Exception as e:
            self.logger.error(f"Error loading state: {e}")
            self._rebuild_all()
            
    def _save_state(self):
        """Сохраняет все состояние"""
        try:
            # Сохраняем документы
            with open(self.cache_dir / 'documents.json', 'w', encoding='utf-8') as f:
                json.dump(self.document_map, f, ensure_ascii=False, indent=2)
                
            # Сохраняем маппинг индексов
            with open(self.cache_dir / 'index_map.json', 'w', encoding='utf-8') as f:
                json.dump(self.index_to_id_map, f)
                
            # Сохраняем FAISS индекс
            if self.index is not None:
                faiss.write_index(self.index, str(self.cache_dir / 'faiss.index'))
                
        except Exception as e:
            self.logger.error(f"Error saving state: {e}")
            
    def _rebuild_all(self):
        """Перестраивает все индексы с нуля"""
        try:
            self.logger.info("Starting complete rebuild...")
            
            # Сбрасываем индекс
            dimension = 384
            self.index = faiss.IndexFlatL2(dimension)
            self.index_to_id_map = []
            
            # Перестраиваем из document_map
            vectors = []
            valid_docs = {}
            
            for doc_id, doc in self.document_map.items():
                try:
                    vector = self.encode_text(doc['chunk_text'])
                    vectors.append(vector)
                    self.index_to_id_map.append(doc_id)
                    valid_docs[doc_id] = doc
                except Exception as e:
                    self.logger.error(f"Error processing doc {doc_id}: {e}")
                    
            if vectors:
                vectors_array = np.array(vectors).astype('float32')
                self.index.add(vectors_array)
                self.document_map = valid_docs
                self._save_state()
                self.logger.info(f"Rebuild complete: {len(vectors)} vectors")
            else:
                self.logger.warning("No valid documents to rebuild from")
                
        except Exception as e:
            self.logger.error(f"Error during rebuild: {e}")
            self._reset()
            
    def _reset(self):
        """Полный сброс состояния"""
        self.index = faiss.IndexFlatL2(384)
        self.index_to_id_map = []
        self.document_map = {}
        self._save_state()
        
    def verify_integrity(self) -> bool:
        """Проверяет целостность всех компонентов"""
        try:
            if self.index is None:
                return False
                
            if len(self.index_to_id_map) != self.index.ntotal:
                self.logger.error(f"Index map size ({len(self.index_to_id_map)}) != vector count ({self.index.ntotal})")
                return False
                
            # Проверяем соответствие document_map и index_to_id_map
            for doc_id in self.index_to_id_map:
                if doc_id not in self.document_map:
                    self.logger.error(f"Document {doc_id} from index map not found in document_map")
                    return False
                    
            return True
            
        except Exception as e:
            self.logger.error(f"Error in verify_integrity: {e}")
            return False
            
    def vectorize_documents(self, documents: dict):
        """Добавляет новые документы"""
        if not documents:
            return
            
        try:
            vectors = []
            new_doc_ids = []
            
            for doc_id, doc in documents.items():
                vector = self.encode_text(doc['chunk_text'])
                vectors.append(vector)
                new_doc_ids.append(doc_id)
                self.document_map[doc_id] = doc
                
            if vectors:
                vectors_array = np.array(vectors).astype('float32')
                self.index.add(vectors_array)
                self.index_to_id_map.extend(new_doc_ids)
                self._save_state()
                
        except Exception as e:
            self.logger.error(f"Error adding documents: {e}")
            if not self.verify_integrity():
                self._rebuild_all()

    def _save_vector(self, doc_id: str, vector: np.ndarray):
        """Сохраняет вектор в кэш"""
        try:
            vector_path = self.cache_dir / f"{doc_id}.npy"
            np.save(vector_path, vector)
        except Exception as e:
            self.logger.error(f"Error saving vector: {e}")

    def _save_index(self):
        """Сохраняет индекс"""
        try:
            faiss.write_index(self.index, str(self.cache_dir / 'faiss.index'))
            self.logger.info(f"Saved index with {self.index.ntotal} vectors")
        except Exception as e:
            self.logger.error(f"Error saving index: {e}")

    def _load_or_create_index(self):
        """Загружает существующий индекс или создает новый"""
        try:
            if self.cache_dir / 'faiss.index'.exists():
                self.index = faiss.read_index(str(self.cache_dir / 'faiss.index'))
                self.logger.info(f"Loaded existing index with {self.index.ntotal} vectors")
            else:
                dimension = 384  # Размерность для all-MiniLM-L6-v2
                self.index = faiss.IndexFlatL2(dimension)
                self.logger.info("Created new empty index")
        except Exception as e:
            self.logger.error(f"Error loading index: {e}")
            dimension = 384
            self.index = faiss.IndexFlatL2(dimension)

    def _load_cached_documents(self):
        """Загружает документы и восстанавливает индекс"""
        try:
            if self.cache_dir / 'documents.json'.exists():
                with open(self.cache_dir / 'documents.json', 'r', encoding='utf-8') as f:
                    self.document_map = json.load(f)
                self.logger.info(f"Loaded {len(self.document_map)} documents from cache")
                
                # Восстанавливаем векторы и индекс
                vectors = []
                for doc_id in self.document_map:
                    vector_path = self._get_cache_path(doc_id)
                    if vector_path.exists():
                        vectors.append(np.load(vector_path))
                
                if vectors:
                    vectors_array = np.array(vectors).astype('float32')
                    dimension = vectors_array.shape[1]
                    self.index = faiss.IndexFlatL2(dimension)
                    self.index.add(vectors_array)
                    self.logger.info(f"Restored index with {len(vectors)} vectors")
                    
                    # Сохраняем индекс
                    faiss.write_index(self.index, str(self.cache_dir / 'faiss.index'))
                else:
                    self.logger.warning("No vectors found in cache")
                    
        except Exception as e:
            self.logger.error(f"Error loading cached documents: {e}")
            self.document_map = {}

    def _save_documents_cache(self):
        """Сохраняет документы в кэш"""
        try:
            with open(self.cache_dir / 'documents.json', 'w', encoding='utf-8') as f:
                json.dump(self.document_map, f)
            self.logger.info(f"Saved {len(self.document_map)} documents to cache")
        except Exception as e:
            self.logger.error(f"Error saving documents cache: {e}")

    def extract_tags(self, text: str) -> Set[str]:
        """Извлекает теги в формате [[tag]] и #tag из текста"""
        # Ищем теги в формате [[tag]]
        wikilinks = re.findall(r'\[\[(.*?)\]\]', text)
        # Ищем теги в формате #tag
        hashtags = re.findall(r'#([\w-]+)', text)
        # Объединяем и очищаем
        tags = set(wikilinks) | set(hashtags)
        return {tag.strip() for tag in tags if tag.strip()}

    def process_document(self, file_path: Path) -> None:
        try:
            self.logger.info(f"Processing document: {file_path}")
            
            # Определяем тип файла и извлекаем текст
            if file_path.suffix.lower() == '.pdf':
                return  # PDF обрабатываются отдельно через PDFHandler
            
            # Пробуем прочитать как текстовый файл
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    text = f.read()
                    
                # Извлекаем теги из текста
                tags = self.extract_tags(text)
                if tags:
                    self.document_map[str(file_path)] = {
                        'file_path': str(file_path),
                        'chunk_text': text,
                        'chunk_index': 0,
                        'file_type': file_path.suffix.lower(),
                        'tags': list(tags)
                    }
                    self.logger.info(f"Found tags in {file_path}: {tags}")

            except UnicodeDecodeError:
                self.logger.warning(f"Skipping binary file: {file_path}")
                return

            if not text:
                self.logger.warning(f"No text extracted from {file_path}")
                return

            chunks = self.chunk_text(text)
            vectors = self.model.encode(chunks, show_progress_bar=True)
            
            start_idx = self.index.ntotal
            self.index.add(vectors)
            
            for i, chunk in enumerate(chunks):
                self.document_map[start_idx + i] = {
                    'file_path': str(file_path),
                    'chunk_text': chunk,
                    'chunk_index': i,
                    'file_type': file_path.suffix.lower(),
                    'tags': list(tags) if tags else []
                }

            self.logger.info(f"Added {len(chunks)} chunks from {file_path}")

        except Exception as e:
            self.logger.error(f"Error processing document {file_path}: {e}")

    def encode_text(self, text: str) -> np.ndarray:
        try:
            return self.model.encode([text])[0]
        except Exception as e:
            self.logger.error(f"Error vectorizing text: {e}")
            return np.zeros(self.model.get_sentence_embedding_dimension())

    def add_to_index(self, vector: np.ndarray, metadata: Dict) -> bool:
        try:
            self.index.add(vector.reshape(1, -1))
            self.document_map[self.index.ntotal - 1] = metadata
            return True
        except Exception as e:
            self.logger.error(f"Error adding to index: {e}")
            return False

    def save_index(self, directory: Path) -> None:
        try:
            directory.mkdir(parents=True, exist_ok=True)
            faiss.write_index(self.index, str(directory / 'vectors.index'))
            with open(directory / 'document_map.pkl', 'wb') as f:
                pickle.dump(self.document_map, f)
        except Exception as e:
            self.logger.error(f"Error saving index: {e}")

    def load_index(self, directory: Path) -> None:
        try:
            self.index = faiss.read_index(str(directory / 'vectors.index'))
            with open(directory / 'document_map.pkl', 'rb') as f:
                self.document_map = pickle.load(f)
        except Exception as e:
            self.logger.error(f"Error loading index: {e}")

    def _get_cache_path(self, doc_id: str) -> Path:
        """Получает путь к кэшу для документа"""
        # Используем хэш для имени файла
        filename = hashlib.md5(doc_id.encode()).hexdigest()
        return self.cache_dir / f"{filename}.npy"

    def _get_document_hash(self, doc: dict) -> str:
        """Создает хеш документа на основе его содержимого и метаданных"""
        content = f"{doc['chunk_text']}{','.join(doc.get('tags', []))}{doc.get('file_path', '')}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def _load_cache_meta(self) -> dict:
        """Загружает метаданные кэша"""
        if self.cache_meta_path.exists():
            try:
                with open(self.cache_meta_path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                self.logger.warning(f"Failed to load cache metadata: {e}")
        return {}
    
    def _save_cache_meta(self):
        """Сохраняет метаданные кэша"""
        try:
            with open(self.cache_meta_path, 'w') as f:
                json.dump(self.cache_meta, f)
        except Exception as e:
            self.logger.warning(f"Failed to save cache metadata: {e}")
    
    def _is_cache_valid(self, doc_id: str, doc: dict) -> bool:
        """Проверяет актуальность кэша для документа"""
        if doc_id not in self.cache_meta:
            return False
            
        current_hash = self._get_document_hash(doc)
        cached_hash = self.cache_meta[doc_id].get('hash')
        
        # Проверяем изменение содержимого
        if current_hash != cached_hash:
            return False
            
        # Проверяем изменение файла на диске
        file_path = Path(doc.get('file_path', ''))
        if file_path.exists():
            mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
            cached_mtime = datetime.fromisoformat(self.cache_meta[doc_id].get('mtime', '1970-01-01'))
            if mtime > cached_mtime:
                return False
                
        return True

    def generate_empty_index(self):
        """Создает пустой индекс если нет данных"""
        if self.index.ntotal == 0:
            # Генерируем тестовый вектор для получения размерности
            test_vector = self.model.encode(["test"])[0]
            dimension = len(test_vector)
            self.index = faiss.IndexFlatL2(dimension)
            self.logger.info(f"Created empty index with dimension {dimension}") 

    def get_index_stats(self) -> dict:
        """Возвращает статистику индекса"""
        return {
            'total_vectors': self.index.ntotal if self.index else 0,
            'total_documents': len(self.document_map),
            'is_valid': self.verify_integrity(),
            'dimension': self.index.d if self.index else None
        } 