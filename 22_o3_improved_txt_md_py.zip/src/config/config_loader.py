from dataclasses import dataclass
from typing import List
from pathlib import Path
import yaml
import logging

@dataclass
class VaultConfig:
    path: str
    supported_extensions: List[str]
    model_name: str
    chunk_size: int
    overlap: int
    mistral_url: str
    timeout: int
    batch_size: int = 10

    @classmethod
    def from_yaml(cls, path: str) -> 'VaultConfig':
        try:
            with open(path, 'r') as f:
                data = yaml.safe_load(f)
            return cls(
                path=data['vault']['path'],
                supported_extensions=data['vault']['supported_extensions'],
                model_name=data['model']['name'],
                chunk_size=data['model']['chunk_size'],
                overlap=data['model']['overlap'],
                mistral_url=data['api']['mistral_url'],
                timeout=data['api']['timeout'],
                batch_size=data.get('processing', {}).get('batch_size', 10)
            )
        except Exception as e:
            logging.error(f"Error loading config: {e}")
            raise 