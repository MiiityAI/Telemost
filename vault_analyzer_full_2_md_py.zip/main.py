from pathlib import Path
from typing import List, Optional
from src.config.config_loader import VaultConfig
from src.document_handlers.pdf_handler import PDFHandler
from src.document_handlers.markdown_handler import MarkdownHandler
from src.indexing.vectorizer import DocumentVectorizer
from src.indexing.batch_processor import BatchProcessor
from src.text_processing.chunker import TextChunker
from src.gui.chat_window import ChatWindow
from src.ai.mistral_client import MistralClient
import logging
from PyQt6.QtWidgets import QApplication
import sys
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

class VaultAnalyzer:
    def __init__(self):
        # Добавляем логгер
        self.logger = logging.getLogger(__name__)
        
        # Исправляем путь к конфигу
        config_path = Path(__file__).parent / 'src' / 'config' / 'config.yaml'
        self.config = VaultConfig.from_yaml(str(config_path))
        
        # Инициализация компонентов
        self.pdf_handler = PDFHandler()
        self.markdown_handler = MarkdownHandler()
        self.vectorizer = DocumentVectorizer(self.config)
        self.chunker = TextChunker(self.config.chunk_size, self.config.overlap)
        self.batch_processor = BatchProcessor(
            batch_size=self.config.batch_size,
            vectorizer=self.vectorizer
        )
        # Добавляем инициализацию Mistral клиента
        self.mistral_client = MistralClient(self.config.mistral_url)
        
        self.logger.info("VaultAnalyzer initialized successfully")

    def process_vault(self) -> None:
        self.logger.info("Starting vault processing")
        
        # Шаг 1: Индексация документов
        processed_docs = 0
        for file_path in Path(self.config.path).rglob('*'):
            if not self._should_process_file(file_path):
                continue
            
            text = self._extract_text(file_path)
            if not text:
                self.logger.warning(f"No text extracted from {file_path}")
                continue
            
            self.batch_processor.add_to_batch(text, {
                'file_path': str(file_path),
                'document_text': text,
                'processed_at': datetime.now().isoformat()
            })
            processed_docs += 1
            self.logger.debug(f"Added document: {file_path}")
        
        self.batch_processor.finalize()
        total_chunks = len(self.vectorizer.document_map)
        self.logger.info(f"Processed {processed_docs} documents into {total_chunks} chunks")

        if total_chunks == 0:
            self.logger.warning("No documents were processed")
            return "No content found for analysis"

        # Шаг 2: Сборка документов из чанков
        all_docs = {}
        for chunk in self.vectorizer.document_map.values():
            file_path = chunk['file_path']
            if file_path not in all_docs:
                all_docs[file_path] = {
                    'file_path': file_path,
                    'content': [],
                    'tags': chunk.get('tags', []),
                    'processed_at': chunk.get('processed_at', '')
                }
            all_docs[file_path]['content'].append(chunk['chunk_text'])
        
        self.logger.info(f"Reconstructed {len(all_docs)} documents from chunks")
        
        # Шаг 3: Анализ по документам
        doc_batch_size = 5  # Уменьшаем размер батча
        insights = []
        
        doc_items = list(all_docs.items())
        total_batches = (len(doc_items) + doc_batch_size - 1) // doc_batch_size
        
        for i in range(0, len(doc_items), doc_batch_size):
            batch_docs = doc_items[i:i + doc_batch_size]
            try:
                batch_summary = "Analyze these documents:\n\n"
                
                for path, doc in batch_docs:
                    content_preview = ''.join(doc['content'])
                    # Берем первую и последнюю части документа
                    if len(content_preview) > 3000:
                        summary = (
                            content_preview[:2000] + 
                            "\n...[middle part omitted]...\n" +
                            content_preview[-1000:]
                        )
                    else:
                        summary = content_preview
                    
                    batch_summary += f"Document: {path}\n"
                    batch_summary += f"Content: {summary}\n"
                    batch_summary += f"Tags: {', '.join(doc['tags'])}\n\n"
                
                batch_insight = self.mistral_client.get_insights(
                    "Analyze these documents and identify:\n"
                    "1. Key topics and themes\n"
                    "2. Main connections between documents\n"
                    "3. Important insights and patterns",
                    batch_summary
                )
                
                if batch_insight:
                    insights.append(batch_insight)
                    self.logger.info(f"Processed document batch {i//doc_batch_size + 1} of {total_batches}")
                else:
                    self.logger.warning(f"Empty insight received for document batch {i//doc_batch_size + 1}")
                
            except Exception as e:
                self.logger.error(f"Error processing document batch {i//doc_batch_size + 1}: {str(e)}")
                continue
        
        if not insights:
            self.logger.warning("No insights were generated")
            return "Analysis failed: no insights could be generated"
        
        # Шаг 4: Финальный анализ
        try:
            self.logger.info("Generating final analysis")
            return self.mistral_client.get_insights(
                "Create a comprehensive analysis of the entire vault, focusing on:\n"
                "1. Main themes and topics across all documents\n"
                "2. Key connections and patterns\n"
                "3. Important insights and findings\n"
                "4. Suggested areas for development",
                "\n---\n".join(insights)
            ) or "Analysis completed but no final summary could be generated"
        except Exception as e:
            self.logger.error(f"Error in final analysis: {str(e)}")
            return "Error during final analysis: " + str(e)

    def _should_process_file(self, file_path: Path) -> bool:
        result = (file_path.is_file() and 
                file_path.suffix.lower() in self.config.supported_extensions)
        if not result and file_path.is_file():
            self.logger.debug(f"Skipping unsupported file: {file_path}")
        return result

    def _extract_text(self, file_path: Path) -> Optional[str]:
        suffix = file_path.suffix.lower()
        if suffix == '.pdf':
            return self.pdf_handler.extract_text(file_path)
        elif suffix == '.md':
            return self.markdown_handler.extract_text(file_path)
        elif suffix in ['.txt', '.py', '.json']:  # и любые другие текстовые форматы
            return self.markdown_handler.extract_text_generic(file_path)
        else:
            return None

    def _process_chunks(self, chunks: List[str], file_path: Path, 
                       processor: BatchProcessor) -> None:
        for i, chunk in enumerate(chunks):
            metadata = {
                'file_path': str(file_path),
                'chunk_index': i,
                'chunk_text': chunk
            }
            processor.add_to_batch(chunk, metadata)

def main():
    # Настраиваем базовое логирование
    logging.basicConfig(level=logging.INFO)
    
    # Инициализируем анализатор
    analyzer = VaultAnalyzer()
    
    # Обрабатываем vault и получаем первичный анализ
    print("Starting vault processing...")
    initial_analysis = analyzer.process_vault()  # Получаем анализ здесь
    print("Vault processing completed")
    
    # Запускаем GUI с уже готовым анализом
    app = QApplication(sys.argv)
    window = ChatWindow(
        vectorizer=analyzer.vectorizer,
        mistral_client=analyzer.mistral_client,
        config=analyzer.config,
        initial_analysis=initial_analysis  # Передаем готовый анализ
    )
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main() 